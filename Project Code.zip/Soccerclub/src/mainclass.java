import java.util.Scanner;
public class mainclass {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Coach cch = new Coach();
		Player ply = new Player();;
		int answer = 0;
		String repeat = "";
		String coachrplayer = "";
		String editcchrply="";
		String deletecchrply="";
		String userfilechoice ="";
		System.out.println("Welcome, Coach to the program that will help you to input your team information");
		
	
		
		do{
			System.out.println("please enter in where you want to go 1. adding people 2. editing 3. printing out 4. deleting people 5. write to file 6.read from file");
			answer= scan.nextInt();
			
			
		switch(answer){
		case 1: 	
			System.out.println("would you like to add a player or a coach");
			scan.nextLine();
			coachrplayer= scan.nextLine();
		if(coachrplayer.equals("coach")){
			System.out.println("hello coach input all the coaches names and their jacketsize");
			cch.coachadd();
			cch.coachname();
			cch.coachassignjacksize();
			cch.printout();
			
			}
		
		else if(coachrplayer.equals("player")){
		
		 System.out.println("hello coach, input all the players names, jerseysize, pantsize and jacketsize ");
		 System.out.println("you can only enter in up to 20 players");
          ply.playeradd();
		  ply.playername();
		  ply.plyjernum();
		  ply.playerassignjersize();
		  ply.playerassignjacksize();
		  ply.playerassignpantsize();
		  ply.printout();
		 
		}
		else{
			System.out.println("invalid input");
		}
		
	    break;
		case 2: 
			System.out.println("you will be editing the database");
			System.out.println("who do you want to edit, a coach or player");
			scan.nextLine();
			editcchrply = scan.nextLine();
		if(editcchrply.equals("coach") & (cch.userinput>0)){
			cch.printout();
			cch.coachedit();
		}
		else if(editcchrply.equals("player") & (ply.userinput>0)) {
			ply.printout();
			ply.playeredit();
		}
		else{
			System.out.println("you either do not have a coach or player entered, please add them");
		}
		break;
		case 3:
			if((cch.userinput>0) & (ply.userinput>0)){
				cch.printout();
				ply.printout();
				scan.nextLine();
			}
		
			else if(ply.userinput>0){
			ply.printout();
			scan.nextLine();
			}
			else if(cch.userinput>0){
				cch.printout();
				scan.nextLine();
			}
			
			break;
		
		case 4:
			System.out.println("you will be deleting elements in the database");
			System.out.println("who do you want to delete, a coach or player");
			scan.nextLine();
			deletecchrply = scan.nextLine();
			if(deletecchrply.equals("coach") & (cch.userinput>0)){
				cch.printout();
				cch.delcoach();
			}
			else if(deletecchrply.equals("player") & (ply.userinput>0)){
				ply.printout();
			    ply.delplayer();
			}
			else{
				System.out.println("you either do not have a coach or player entered, please add them");
			}
			break;
		case 5:
			System.out.println(" files are written with the information you have entered called Playersend.txt and Coachsend.txt ");
			System.out.println("you can use these files to send off to the companies");
			if((cch.userinput>0) & (ply.userinput>0)){
				ply.plysendwritetofile();
				ply.plywritetofile();
				cch.coachwritetofile();
				cch.coachsendwritetofile();
				System.out.println("end of program");
			}
		
			else if(ply.userinput>0){
				ply.plysendwritetofile();
				ply.plywritetofile();
				System.out.println("end of program");
			}
			else if(cch.userinput>0){
				cch.coachwritetofile();
				cch.coachsendwritetofile();
				System.out.println("end of program");
			}
			
			break;
		case 6:
			System.out.println("you can read the data from the previous files you created Coachread.txt and Playerread.txt");
			System.out.println("what do you want to choose a coach or a player");
			scan.nextLine();
			userfilechoice = scan.nextLine();
			if(userfilechoice.equals("coach") ){
				System.out.println("got it from coach");
				cch.coachreadtofile();
			 
			}
			else if (userfilechoice.equals("player")){
				System.out.println("got it from player");
				ply.playerreadtofile();
			}
			
			break;
		
		}
		
		
		System.out.println(" if you want to repeat 'yes' ");
		repeat = scan.nextLine();
	}while(repeat.equals("yes"));
		
		
		

	}

}
