import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
public class Members extends Persons   {
	
    int max =21;
	public Members[] memb = new Members[max];
	private int i=0;
	private String username;
	private char jersize;
	private int jerseynum;
	private char jacksize;
	private char pntsize;
	int namecurrent=0;
	int jercurrent=0;
	int jackcurrent=0;
	int userinput=0;
	int numof=0;
	int pantcurrent=0;
	int jerseynumcurrent;
	private String askname;
	private String newname;
	private String delname;
	private char newjersize;
	private char newjacksize;
	Scanner myscan = new Scanner(System.in);
	
	
		
	
	public void addmember(){
		System.out.println("how many people would you like to add");
		numof = myscan.nextInt();
		myscan.nextLine();
		if ((numof + userinput) < memb.length){
			for(int i = 0 ; i<numof; i++)
			{
                memb[userinput] = new Members();
				userinput = userinput +1;
					}
			}
		else
		{
			System.out.println(numof+" new members will exceed the number of legit members");
		}
	
	}
	public void assignname(){
		
			for(i =0; i<numof ; i++){
			System.out.println("enter in the name of person " + (namecurrent+1));
			username = myscan.nextLine();
		    memb[namecurrent].name(username);
		    namecurrent = namecurrent+1;
			
			}
			
		}
		public void assignjersize(){
			for(i =0; i<numof; i++){
			System.out.println("type 's' for small, 'm' for medium and 'l' for large");
			System.out.println("enter the jersize for " + memb[jercurrent].getusername());
			jersize = myscan.next().charAt(0);
			memb[jercurrent].jersize(jersize);
			jercurrent = jercurrent+1;
			}
			
			
		}
		public void jerseynummemb(){
			for(i =0; i<numof; i++){
				System.out.println("enter the jerseynumber for " + memb[jerseynumcurrent].getusername());
				jerseynum = myscan.nextInt();
				memb[jerseynumcurrent].jerseynumber(jerseynum);
				jerseynumcurrent= jerseynumcurrent+1;
			}
		}
		public void assignjacksize(){
			for(i=0; i<numof; i++){
				System.out.println("type 's' for small, 'm' for medium and 'l' for large");
				System.out.println("enter in the jacket size for " + memb[jackcurrent].getusername());
				jacksize = myscan.next().charAt(0);
				memb[jackcurrent].jacksize(jacksize);
				jackcurrent = jackcurrent +1;
			}
		}
		public void assignpantsize(){
			for(i = 0; i<numof; i++){
				System.out.println("type 's' for small, 'm' for medium and 'l' for large");
				System.out.println("enter in the shortsize for " + memb[pantcurrent].getusername());
				pntsize = myscan.next().charAt(0);
				memb[pantcurrent].pantsize(pntsize);
				pantcurrent = pantcurrent +1;
			}
		}
		
		
		public void printout(){
			for(i=0; i<userinput; i++){
				System.out.println("The name of " + (i+1) + '\t' + memb[i].getusername());
				System.out.println("the jersey size is " + (i+1) + '\t' +  memb[i].getjersize());
				System.out.println("The jacket size of " + (i+1) + '\t' + memb[i].getjacksize());
				
				
			}
		}
	
		public void editname(){
			System.out.println("which person do you want to edit");
			myscan.nextLine();
			askname = myscan.nextLine();
			for(i = 0; i<userinput; i++){
			if(askname.equals( memb[i].getusername())){
				System.out.println("found name");
				System.out.println("what would you like to change it to");
				newname = myscan.nextLine();
				 memb[i].name(newname);
			System.out.println(memb[i].getusername());
			System.out.println("what would you like to change the jersize to");
			newjersize = myscan.next().charAt(0);
			memb[i].jersize(newjersize);
			System.out.println("what would you like to change the jacketsize to");
			newjacksize = myscan.next().charAt(0);
			memb[i].jacksize(newjacksize);
			System.out.println("editing has finished");
			}
			else{
				System.out.println("invalid input");
			}
			}
		}
		public void deletename(){
			String prevname;
			System.out.println("which person do you want to delete");
			myscan.nextLine();
			delname= myscan.nextLine();
			for(i = 0; i<userinput; i++){
			if(delname.equals(memb[i].getusername())){
				System.out.println("name found");
				 prevname = memb[userinput-1].getusername();
				memb[i].name(prevname);
				userinput = userinput-1;
				}
			
			}
		}
		
	
public void ReadFile()
{
	// Get data from txt file
	Scanner inputStream = null;
	try
	{
		inputStream = new Scanner(new FileInputStream("Soccer.txt"));
	}
	catch(FileNotFoundException e)
	{
		System.out.println("file can not be found or not opened");
		System.exit(0);
	}
	userinput = inputStream.nextInt();
	String empty = inputStream.nextLine();
	int i = 0;
	while (i<userinput &&i<max)
			{
				memb[i] = new Members();
				memb[i].name(inputStream.nextLine()) ;
				memb[i].jerseynumber(inputStream.nextInt());
				memb[i].jersize(inputStream.next().charAt(0));
				memb[i].jacksize(inputStream.next().charAt(0));
				memb[i].pantsize(inputStream.next().charAt(0));
				empty = inputStream.nextLine();
				i++;
			}
}
public void WriteToFile()
{
	PrintWriter outputStream = null;
	try
	{
		outputStream = new PrintWriter(new FileOutputStream("Soccer.txt"));
	}
	catch (FileNotFoundException e)
	{
		System.out.println("Error oping the file");
		System.exit(0);
	}
	System.out.println("Writing to file");
	for(int j = 0; j<userinput; j=j+1)
	{
		
		outputStream.println(memb[j].getusername() );
		outputStream.println(memb[j].getjersize());
		outputStream.println(memb[j].getjacksize());
	}
	outputStream.println("the end");
	outputStream.close();
	System.out.println("Written to file");
}
}
	
		

	
		

		
		
			
		
		



		// TODO Auto-generated method stub
		
	
	
	
	


