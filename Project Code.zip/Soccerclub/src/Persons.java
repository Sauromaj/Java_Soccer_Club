
import java.util.Scanner;
/*
 * 
 */
public class Persons {
	Scanner myscan = new Scanner(System.in);
	String thename;
    char jerseysize;
    char jacketsize;
    char pantsize;
	int jerseynum;
	
	public void name(String name){
		thename = name;
	}
	public String getusername(){
		return thename;
		}
	
	public void jerseynumber(int jernum){
		jerseynum = jernum;
	}
	public int getjerseynum(){
		return jerseynum;
	}
	public void jersize(char jersize){
		jerseysize = jersize;
	}
	public char getjersize(){
		return jerseysize;
	}
	public void pantsize(char pntsize){
		 pantsize = pntsize;
	}
	public char getpntsize() {
		return pantsize;
	}
	
	public void jacksize(char jacksize) {
		jacketsize = jacksize;
	}
	public char getjacksize(){
		return jacketsize;
	}
	
	
	

	
  
	

}
