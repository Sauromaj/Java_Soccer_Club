import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
public class Player extends Members {
	private String askname;
	private String newname;
	private char newjersize;
	private char newjacksize;
	private char newpntsize;
    private String delname;
    private boolean plyedit;
    private boolean plydel;
    private int newjernum;
    private String username;
    private int plynamecurrent;
	Scanner myscan = new Scanner(System.in);
	
	public void playeradd(){
		
		 super.addmember();
		
			
			}
		public void playerassignjacksize(){
			super.assignjacksize();
		}
		public void playername() 
		{
			for(int i =0; i<numof ; i++){
				System.out.println("enter in the name of player " + (plynamecurrent+1));
				username = myscan.nextLine();
			    memb[plynamecurrent].name(username);
			    plynamecurrent = plynamecurrent+1;
			}
		}
		public void printout() 
		{
			for(int i = 0; i<userinput; i++){
				System.out.println("The name of player " + (i+1) + '\t' + memb[i].getusername());
				System.out.println("the jerseynumber for player " + (i+1) + '\t' + "is " + memb[i].getjerseynum() );
				System.out.println("the jersey size of player " + (i+1) + '\t' +  memb[i].getjersize());
				System.out.println("The jacket size of player " + (i+1) + '\t' + memb[i].getjacksize());
				System.out.println(" the shortsize of player" + (i+1) + '\t' + memb[i].getpntsize());
				
			}
	
		}
		public void playerassignjersize() 
		{
			super.assignjersize();
			
		}
		public void plyjernum(){
			super.jerseynummemb();
		}
		public void playerassignpantsize(){
			super.assignpantsize();
		}
		
		public void playeredit(){
			
				System.out.println("which person do you want to edit");
				askname = myscan.nextLine();
				for( int i = 0; i<userinput; i++){
				if(askname.equalsIgnoreCase( memb[i].getusername())){
					System.out.println("found name");
					System.out.println("what would you like to change it to");
					newname = myscan.nextLine();
					 memb[i].name(newname);
				System.out.println("what would you like to change the jerseynum to");
				newjernum = myscan.nextInt();
				memb[i].jerseynumber(newjernum);
				myscan.nextLine();
				System.out.println("what would you like to change the jersize to");
				newjersize = myscan.next().charAt(0);
				memb[i].jersize(newjersize);
				System.out.println("what would you like to change the jacketsize to");
				newjacksize = myscan.next().charAt(0);
				memb[i].jacksize(newjacksize);
				System.out.println("what would you like to change the shortsize to");
				newpntsize = myscan.next().charAt(0);
				memb[i].pantsize(newpntsize);
				plyedit = true;
				}
				
				}
				if(plyedit){
					System.out.println("editing has finished");
				}
				else{
					System.out.println("invalid input");
				}
			}
			
		
		public void delplayer(){
			String prevname;
			char prevjersize,prevjacksize,prevpantsize;
			int prevjernum;
			System.out.println("which person do you want to delete");
			myscan.nextLine();
			delname= myscan.nextLine();
			for( int i = 0; i<userinput; i++){
			if(delname.equalsIgnoreCase(memb[i].getusername())){
				System.out.println("name found");
				 prevname = memb[userinput-1].getusername();
				memb[i].name(prevname);
				userinput = userinput-1;
				plynamecurrent = plynamecurrent -1;
				prevjersize = memb[jercurrent-1].getjersize();
				memb[i].jersize(prevjersize);
				jercurrent = jercurrent -1;
				prevjacksize = memb[jackcurrent-1].getjacksize();
				memb[i].jacksize(prevjacksize);
				jackcurrent = jackcurrent -1;
				prevpantsize = memb[pantcurrent-1].getpntsize();
				memb[i].pantsize(prevpantsize);
				pantcurrent = pantcurrent -1;
				prevjernum = memb[jerseynumcurrent-1].getjerseynum();
				memb[i].jerseynumber(prevjernum);
				jerseynumcurrent = jerseynumcurrent-1;
				plydel = true;
				}
			}
			if(plydel){
				System.out.println("deleting has finished");
			}
			else{
				System.out.println("invalid input");
			}
			
			
			
		}
		public void playerreadtofile()
		{
			// Get data from txt file
			Scanner inputStream = null;
			try
			{
				inputStream = new Scanner(new FileInputStream("Playerread.txt"));
			}
			catch(FileNotFoundException e)
			{
				System.out.println("file can not be found or not opened");
				System.exit(0);
			}
			userinput = inputStream.nextInt();
			plynamecurrent = userinput;
			jackcurrent = userinput;
			jercurrent = userinput;
			pantcurrent = userinput;
			jerseynumcurrent = userinput;
			String empty = inputStream.nextLine();
			int i = 0;
			while (i<userinput &&i<max)
					{
						memb[i] = new Members();
						memb[i].name(inputStream.nextLine()) ;
						memb[i].jerseynumber(inputStream.nextInt());
						empty = inputStream.nextLine();
						memb[i].jersize(inputStream.next().charAt(0));
						memb[i].jacksize(inputStream.next().charAt(0));
						memb[i].pantsize(inputStream.next().charAt(0));
						empty = inputStream.nextLine();
						i++;
					}
		}
		public void plysendwritetofile(){
			PrintWriter outputStream = null;
			try
			{
				outputStream = new PrintWriter(new FileOutputStream("Playersend.txt"));
			}
			catch (FileNotFoundException e)
			{
				System.out.println("Error oping the file");
				System.exit(0);
			}
			System.out.println("Writing to file");
			outputStream.println("there are " + userinput + " players");
			for(int j = 0; j<userinput; j=j+1)
			{
				
				outputStream.println("name:" + memb[j].getusername());
				outputStream.println("jerseynumber: " + memb[j].getjerseynum());
				outputStream.println("jerseysize:" + memb[j].getjersize());
				outputStream.println("jacketsize:" + memb[j].getjacksize());
				outputStream.println("shortsize:" + memb[j].getpntsize());
	
				
			}
			outputStream.println("the end");
			outputStream.close();
			System.out.println("Written to file");
		}
		public void plywritetofile(){
			PrintWriter outputStream = null;
			try
			{
				outputStream = new PrintWriter(new FileOutputStream("Playerread.txt"));
			}
			catch (FileNotFoundException e)
			{
				System.out.println("Error oping the file");
				System.exit(0);
			}
			System.out.println("Writing to file");
			outputStream.println( userinput );
			for(int j = 0; j<userinput; j=j+1)
			{
				
				outputStream.println(memb[j].getusername());
				outputStream.println(memb[j].getjerseynum());
				outputStream.println(memb[j].getjersize());
				outputStream.println(memb[j].getjacksize());
				outputStream.println(memb[j].getpntsize());
				
			}
			outputStream.println("the end");
			outputStream.close();
			System.out.println("Written to file");
		}
		
		

}
